#include <stdio.h>
#include "xhhead.h"

main()
{
xhhed x;
fprintf(stdout,"size= %d\n", sizeof(x));
}
